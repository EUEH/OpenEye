package com.eueh.openeye.concern;

import com.eueh.openeye.R;
import com.eueh.openeye.base.BaseFragment;

/**
 * Created by dllo on 16/12/19.
 */

//关注页  陈小飞负责
public class ConcernFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_concern;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
