package com.eueh.openeye.selection;

import com.eueh.openeye.R;
import com.eueh.openeye.base.BaseFragment;

/**
 * Created by dllo on 16/12/19.
 */

public class SelectionFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_selection;
    }


    @Override
    public void initView() {
//去问问企鹅我去恶趣味
//        pppp

    }

    @Override
    public void initData() {

    }
}
